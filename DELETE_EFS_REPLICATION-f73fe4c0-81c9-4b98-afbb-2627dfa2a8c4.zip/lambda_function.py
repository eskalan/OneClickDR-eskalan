import boto3
import json
def lambda_handler(event, context):
    efs = boto3.client('efs')
    # Get the replication configuration ID from the event
    # replication_configuration_id = event['ReplicationConfigurationId']
    replication_configuration_id = os.environ.get('replication_configuration_id')
    print(replication_configuration_id)
    try:
        # Delete the replication configuration
        response = efs.delete_replication_configuration(
            SourceFileSystemId = replication_configuration_id
        )
        return {
            'statusCode': 200,
            'body': json.dumps('Replication configuration deleted successfully'),
            'Response': response
        }
    except Exception as e:
        print(f"Error deleting replication configuration: {e}")
        return {
            'statusCode': 500,
            'body': f"Error deleting replication configuration: {e}"
        }