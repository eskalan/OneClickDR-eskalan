import boto3
import json
import os
def lambda_handler(event, context):
    ssm_client = boto3.client('ssm')
    # Get the instance ID and document name from the event or environment variables
    #instance_id = event.get('InstanceId', os.getenv('INSTANCE_ID'))
    #document_name = event.get('DocumentName', os.getenv('DOCUMENT_NAME'))
    instance_id = os.environ.get('instance_id')
    print(instance_id)
    document_name = os.environ.get('document_name')
    if not instance_id or not document_name:
        return {
            'statusCode': 400,
            'body': json.dumps('InstanceId and DocumentName are required')
        }
    try:
        response = ssm_client.send_command(
            InstanceIds=[instance_id],
            DocumentName=document_name,
            
        )
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'SSM Document executed successfully',
                'response': response
            })
        }
    except Exception as e:
        print(f"Error executing SSM Document: {e}")
        return {
            'statusCode': 500,
            'body': f"Error executing SSM Document: {e}"
        }