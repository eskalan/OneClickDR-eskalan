import boto3
import json
import os
def lambda_handler(event, context):
    # Initialize AWS DRS client
    drs = boto3.client('drs')
    # Get the SourceServerID from the event or environment variable
    # source_server_id = event.get('SourceServerID', os.getenv('DEFAULT_SOURCE_SERVER_ID'))
    source_server_id = os.environ.get('SourceServerID')
    print(source_server_id)
    try:
        # Start recovery drill
        response = drs.start_recovery(
            isDrill=True,
            sourceServers=[
                {
                    'sourceServerID': source_server_id
                }
           ])
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Recovery drill initiated successfully',
                'response': response
            })
        }
    except Exception as e:
        print(f"Error initiating recovery drill: {e}")
        return {
            'statusCode': 500,
            'body': f"Error initiating recovery drill: {e}"
        }
